<!-- ======= Footer ======= -->
  <footer>
    <div class="container " >
      <div class="row">
        <div class="col-md-12">
          <nav class="nav-footer">
            <ul class="list-inline">
              <li class="list-inline-item">
                <a href="home">Beranda</a>
              </li>
              <li class="list-inline-item">
                <a href="about">Tentang</a>
              </li>
              <li class="list-inline-item">
                <a href="property">Properti</a>
              </li>
              <li class="list-inline-item">
                <a href="kontak">Hubungi kami</a>
              </li>
            </ul>
          </nav>
          <div class="socials-a">
            <ul class="list-inline">
              <li class="list-inline-item">
                <a href="#">
                  <i class="fa fa-facebook" aria-hidden="true"></i>
                </a>
              </li>
              <li class="list-inline-item">
                <a href="#">
                  <i class="fa fa-twitter" aria-hidden="true"></i>
                </a>
              </li>
              <li class="list-inline-item">
                <a href="#">
                  <i class="fa fa-instagram" aria-hidden="true"></i>
                </a>
              </li>
              <li class="list-inline-item">
                <a href="#">
                  <i class="fa fa-pinterest-p" aria-hidden="true"></i>
                </a>
              </li>
              <li class="list-inline-item">
                <a href="#">
                  <i class="fa fa-dribbble" aria-hidden="true"></i>
                </a>
              </li>
            </ul>
          </div>
          <div class="copyright-footer">
            <p class="copyright color-text-a">
              &copy; Copyright
              <span class="color-a">WishProperty</span> All Rights Reserved.
            </p>
          </div>
          <div class="credits">
            <!--
            All the links in the footer should remain intact.
            You can delete the links only if you purchased the pro version.
            Licensing information: https://bootstrapmade.com/license/
            Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=EstateAgency
          -->
          </div>
        </div>
      </div>
    </div>
  </footer><!-- End  Footer -->
  <!--
  <a href="http://example.com" onclick="window.open(this.href, '_blank', 'left=20,top=20,width=500,height=500,toolbar=1,resizable=0'); return false;">
  <img class="chat" src="gambar/blog/chaticon.png" height="150px" width="150px" style="display: inline;"></a>
  -->
  
<input type="checkbox" id="check"> 
<label class="chat-btn" for="check"> 
  

<img src="<?php echo base_url('gambar/blog/chaticon.png') ?>" height="150px" width="150px" style="display: inline;"></label>
<div class="wrapper"  style="display: inline-block; ">
    <div class="header">
        <h6 align="center">Tanya ke CS - <b>Online</b></h6>
    </div>
    <div class="text-center p-2"> <span>Selamat Datang Wish Properti</span> </div>
    <div class="chat-form"> 
    <center>
    <h5>Hubungi melalui whatsapp</h5>
    <a href="https://wa.me/6281234121237?text=Hallo Wishproperti?">
    <img src="<?php echo base_url('assetss/img/wa.png')?>" width="150px"></a>
    <br><br>
    </center>
    </div>
</div>

  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="<?= base_url('assetss/'); ?>vendor/jquery/jquery.min.js"></script>
  <script src="<?= base_url('assetss/'); ?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?= base_url('assetss/'); ?>vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="<?= base_url('assetss/'); ?>vendor/php-email-form/validate.js"></script>
  <script src="<?= base_url('assetss/'); ?>vendor/owl.carousel/owl.carousel.min.js"></script>
  <script src="<?= base_url('assetss/'); ?>vendor/scrollreveal/scrollreveal.min.js"></script>

  <!-- Template Main JS File -->
  <script src="<?= base_url('assetss/'); ?>js/main.js"></script>

</body>

</html>